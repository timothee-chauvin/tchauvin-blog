window.YTD.note_tweet.part0 = [
  {
    "noteTweet": {
      "noteTweetId": "999110",
      "createdAt": "2026-06-23T09:00:00.000Z",
      "core": {
        "text": "This is a long post that got cut right about here, but the note carries the full text, including a link https://t.co/fff at the end",
        "urls": [
          {
            "shortUrl": "https://t.co/fff",
            "expandedUrl": "https://example.com/long-read"
          }
        ]
      }
    }
  },
  {
    "noteTweet": {
      "noteTweetId": "999112",
      "createdAt": "2026-06-24T09:00:00.000Z",
      "core": {
        "text": "I wrote about this https://t.co/NEW2 and then some more thoughts that got cut",
        "urls": [
          {
            "shortUrl": "https://t.co/NEW2",
            "expandedUrl": "https://example.com/essay"
          }
        ]
      }
    }
  },
  {
    "noteTweet": {
      "noteTweetId": "999111",
      "createdAt": "2026-06-23T09:00:00.000Z",
      "core": {
        "text": "A colliding note that must NOT be matched",
        "urls": []
      }
    }
  }
]